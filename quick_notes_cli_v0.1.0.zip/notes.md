# Quick Notes

A lightweight, timestamped notes file.

- [2025-09-10 09:45:44] First note  shipped the Quick Notes CLI skeleton
- [2025-09-10 09:45:44] Plan: build Focus Timer next
- [2025-09-10 10:39:46] Toolbelt test note
